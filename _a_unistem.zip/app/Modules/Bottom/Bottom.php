<?php

namespace App\Modules\Bottom;

use Illuminate\Database\Eloquent\Model;

class Bottom extends Model
{
    protected $fillable = [
        'address',
    ];
}
