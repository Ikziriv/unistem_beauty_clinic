<?php

namespace App\Modules\Comment\Http\Controllers;

use Illuminate\Http\Request;
use App\ {
	Modules\Comment\Comment,
	Http\Controllers\Controller
};

use Illuminate\Http\Request;

class CommentController extends Controller
{
    //
}
