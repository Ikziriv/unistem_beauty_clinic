<?php $__env->startSection('header'); ?>
  <header role="banner" class="probootstrap-header py-4">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-12 mb-5">
          <a href="#" class="mr-auto"><img src="<?php echo e(url('_frontend/img/logo_text.png')); ?>" width="268" height="68" class="hires" alt="Unistem"></a>
        </div>  
        <div class="col-md-9 col-sm-12 mt-2">
          <div class="float-md-right float-none">
          <div class="probootstrap-contact-phone d-flex align-items-top mb-3 float-right text-right">
            <span class="probootstrap-text"> +6221 29629111 
              <small class="d-block"><a href="/appointment" class="arrow-link">Appointment <i class="icon-chevron-right"></i></a></small>
            </span><span class="icon ml-2"><a href="https://api.whatsapp.com/send?phone=15551234567"><i class="icon-phone"></i></a></span>
          </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <section class="intro">
    <div class="container">
      <div class="row">
        <div class="col-md-12 mb-5">
          <div id="myCarousel" class="carousel slide carousel-fade" data-ride="carousel">
          <div class="carousel-inner">
            <div class="carousel-item active">
              <div class="mask flex-center">
                <div class="container">
                  <div class="row align-items-center">
                    <div class="col-md-7 col-12 order-md-2 order-2">
                      <h4>Health <br>
                        awesome product</h4>
                      <p>Lorem ipsum dolor sit amet. Reprehenderit, qui blanditiis quidem rerum <br>
                        necessitatibus praesentium voluptatum deleniti atque corrupti.</p>
                       </div>
                    <div class="col-md-5 col-12 order-md-2 order-1"><img src="<?php echo e(asset('img/model/model2.png')); ?>" class="mx-auto" alt="slide"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="mask flex-center">
                <div class="container">
                  <div class="row align-items-center">
                    <div class="col-md-7 col-12 order-md-2 order-2">
                      <h4>Health <br>
                        awesome product</h4>
                      <p>Lorem ipsum dolor sit amet. Reprehenderit, qui blanditiis quidem rerum <br>
                        necessitatibus praesentium voluptatum deleniti atque corrupti.</p>
                       </div>
                    <div class="col-md-5 col-12 order-md-2 order-1"><img src="<?php echo e(asset('img/model/model2.png')); ?>" class="mx-auto" alt="slide"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item">
              <div class="mask flex-center">
                <div class="container">
                  <div class="row align-items-center">
                    <div class="col-md-7 col-12 order-md-2 order-2">
                      <h4>Health <br>
                        awesome product</h4>
                      <p>Lorem ipsum dolor sit amet. Reprehenderit, qui blanditiis quidem rerum <br>
                        necessitatibus praesentium voluptatum deleniti atque corrupti.</p>
                       </div>
                    <div class="col-md-5 col-12 order-md-2 order-1"><img src="<?php echo e(asset('img/model/model2.png')); ?>" class="mx-auto" alt="slide"></div>
                  </div>
                </div>
              </div>
            </div>
          </div> 
          
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="probootstrap-services">
    <div class="container">
      <div class="row no-gutters">
        <div class="col-md-3 probootstrap-aside-stretch-left">
          <div class="mb-3">
            <h2 class="h6 text-white">Departments</h2>
            <ul class="list-unstyled probootstrap-light mb-4">
              <?php $__empty_1 = true; $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li><a href="<?php echo e(route('front-department-detail', $v->id)); ?>"><?php echo e($v->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <li><a href="#">Not Set</a></li>
              <?php endif; ?>
            </ul>
            <p><a href="/department" class="arrow-link text-white">More departments  <i class="icon-chevron-right"></i></a></p>
          </div>
        </div>
        <div class="col-md-9 pl-md-5 pl-0">
          <div class="row mb-5">
              
              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-price-tag display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Medical Pricing</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-shield-with-cross display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Quality &amp; Safety</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-first-aid-kit display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Immidiate Service</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>

              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-microscope display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Cutting-Edge Equipment</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-gym-control-of-exercises-with-a-list-on-a-clipboard-and-heart-beats display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Personalized Treatment</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-6">
                <div class="media d-block mb-4 text-left probootstrap-media">
                  <div class="probootstrap-icon mb-3"><span class="flaticon-doctor display-4"></span></div>
                  <div class="media-body">
                    <h3 class="h5 mt-0 text-secondary">Experience Physicians</h3>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia.</p>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
  </section>
  
  <section class="probootstrap-blog-appointment">
    <div class="container">
      <div class="row no-gutters">
        <div class="col-md-6 p-md-5 p-3 probootstrap-aside-stretch-left" style="background: #f2f2f2  !important;">
          <h2 class="h1" style="color:#e1b12c;">Make an Appointment</h2>
          <form action="<?php echo e(route('front-appointment-send')); ?>" method="POST" class="probootstrap-form-appointment">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <input type="text" class="form-control" name="name" placeholder="Your Name">
            </div>
            <div class="form-group">
              <input type="email" class="form-control" name="email" placeholder="Your Email">
            </div>
            <div class="form-group">
              <span class="icon"><i class="icon-calendar"></i></span>
              <input type="text" id="probootstrap-date" class="form-control" name="scheduled_time" placeholder="Appointment Date">
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" id="" cols="30" rows="10" placeholder="Write your message"></textarea>
            </div>
            <div class="form-group">
              <input type="submit" value="Submit Form" class="btn btn-primary">
            </div>
          </form>
        </div>
        <div class="col-md-6 pl-md-5 pl-0 pt-md-5 pt-0 pb-md-5 pb-0">
          <h2 class="h1 mb-4 text-white">Testimonial</h2>
          <ul class="probootstrap-blog-list list-unstyled">
            <li>
              <h2>Yully<span class="date"><small>November 15, 2017</small></span><a href="#">
              </a></h2>
              <p>
                "Facial gold nya enak banget, kulit wajah terlihat lebih segar dan kencang seketika setelah perawatan facial ini. Wajib coba de Facial gold nya!"</p>
            </li>
            <li>
              <h2>Yully<span class="date"><small>November 15, 2017</small></span><a href="#">
              </a></h2>
              <p>
                "Facial gold nya enak banget, kulit wajah terlihat lebih segar dan kencang seketika setelah perawatan facial ini. Wajib coba de Facial gold nya!"</p>
            </li>
            <li>
              <h2>Yully<span class="date"><small>November 15, 2017</small></span><a href="#">
              </a></h2>
              <p>
                "Facial gold nya enak banget, kulit wajah terlihat lebih segar dan kencang seketika setelah perawatan facial ini. Wajib coba de Facial gold nya!"</p>
            </li>
          </ul>
          <p><a href="#" class="arrow-link">View All  <i class="icon-chevron-right"></i></a></p>
        </div>
      </div>
    </div>
  </section>

  <section class="probootstrap-section bg-light">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-12 text-left">
          <h2 class="h1">Our Blog</h2>
          <p class="lead text-secondary">Far far away, behind the word mountains, far from the countries Vokalia.</p>
        </div>
      </div>
      <div class="row no-gutters">
        <a href="<?php echo e(route('front-blog')); ?>" class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <div class="probootstrap-person-text text-left">
            <span class="name">Title Blog</span>
            <span class="title">Description</span>
          </div>
          <img src="<?php echo e(url('_frontend/images/person_1.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
        </a>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>