<!DOCTYPE html>
<html lang="en">
<head>
  <title>Unistem International</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="RID" />
  
  <link id="favicon" rel="shortcut icon" href="<?php echo e(url('_frontend/img/logo.png')); ?>" type="image/png">
  <link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">
  <?php echo $__env->make('frontend.partials.assets.css.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>
  <?php echo $__env->make('frontend.partials.component.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END nav -->
  <?php echo $__env->yieldContent('header'); ?>

  <?php echo $__env->yieldContent('content'); ?>

  <section class="probootstrap-section overlay bg-image" style="background-image: url(<?php echo e(url('_frontend/images/bg_1.jpg')); ?>)">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h2 class="text-white display-4">Specialists in Family  Healthcare</h2>
          <p class="text-white mb-5 lead">Far far away, behind the word mountains, far from the countries Vokalia.</p>
          <div class="row justify-content-center mb-5">
            <div class="col-md-4"><a href="/appointment" class="btn btn-secondary btn-block">Appointment <span class="icon-arrow-right"></span></a></div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="probootstrap-blog-appointment">
    <div class="container">
      <div class="row no-gutters">
        <div class="col-md-6 pr-md-5 pr-0 pt-md-5 pt-0 pb-md-5 pb-0">
          <h2 class="h1 mb-4 text-white">Testimonial</h2>
          <ul class="probootstrap-blog-list list-unstyled">
            <li>
              <h2>Yully<span class="date"><small>November 15, 2017</small></span><a href="#">
              </a></h2>
              <p>
                "Facial gold nya enak banget, kulit wajah terlihat lebih segar dan kencang seketika setelah perawatan facial ini. Wajib coba de Facial gold nya!"</p>
            </li>
          </ul>
          <p><a href="#" class="arrow-link">View All  <i class="icon-chevron-right"></i></a></p>
        </div>
        <div class="col-md-6 p-md-5 p-3 probootstrap-aside-stretch-right">
          <h2 class="h1 text-white">Make an Appointment</h2>
          <form action="<?php echo e(route('front-appointment-send')); ?>" method="POST" class="probootstrap-form-appointment">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <input type="text" class="form-control" name="name" placeholder="Your Name">
            </div>
            <div class="form-group">
              <input type="email" class="form-control" name="email" placeholder="Your Email">
            </div>
            <div class="form-group">
              <span class="icon"><i class="icon-calendar"></i></span>
              <input type="text" id="probootstrap-date" class="form-control" name="scheduled_time" placeholder="Appointment Date">
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" id="" cols="30" rows="10" placeholder="Write your message"></textarea>
            </div>
            <div class="form-group">
              <input type="submit" value="Submit Form" class="btn btn-secondary">
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <section class="probootstrap-section bg-light">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-12 text-center">
          <h2 class="h1">Our Doctors</h2>
          <p class="lead text-secondary">Far far away, behind the word mountains, far from the countries Vokalia.</p>
          <div class="row justify-content-center mb-5">
            <div class="col-md-3"><a href="#" class="btn btn-secondary btn-block">Join Us</a></div>
          </div>
        </div>
      </div>
      <div class="row no-gutters">
        <?php $doctor = App\Modules\Doctor\DoctorSub::all()->take(4); ?>
        <?php $__empty_1 = true; $__currentLoopData = $doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <img src="<?php echo e(url('_frontend/images/person_1.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
          <div class="probootstrap-person-text">
            <span class="title">Medical Doctor</span>
            <span class="name">Dr. Abbey Smith</span>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <img src="<?php echo e(url('_frontend/images/person_1.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
          <div class="probootstrap-person-text">
            <span class="title">Medical Doctor</span>
            <span class="name">Dr. Abbey Smith</span>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <img src="<?php echo e(url('_frontend/images/person_2.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
          <div class="probootstrap-person-text">
            <span class="title">Medical Doctor</span>
            <span class="name">Dr. Ben Carpio</span>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <img src="<?php echo e(url('_frontend/images/person_3.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
          <div class="probootstrap-person-text">
            <span class="title">Medical Doctor</span>
            <span class="name">Dr. Louisa Westwood</span>
          </div>
        </div>
        <div class="col-lg-3 col-md-3 col-sm-6 col-6 prbootstrap-team">
          <img src="<?php echo e(url('_frontend/images/person_4.jpg')); ?>" alt="Free Template by uicookies.com" class="img-fluid">
          <div class="probootstrap-person-text">
            <span class="title">Cardiac Surgeon</span>
            <span class="name">Dr. Mark Sebastian</span>
          </div>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <section class="probootstrap-section" id="section-counter">
      <div class="container">
        <div class="row">
          <div class="col-md probootstrap-animate">
            <div class="probootstrap-counter text-center">
              <span class="probootstrap-number" data-number="22">0</span>
              <span class="probootstrap-label">Founders</span>
            </div>
          </div>
          <div class="col-md probootstrap-animate">
            <div class="probootstrap-counter text-center">
              <span class="probootstrap-number" data-number="182">0</span>
              <span class="probootstrap-label">Number of Staffs</span>
            </div>
          </div>
          <div class="col-md probootstrap-animate">
            <div class="probootstrap-counter text-center">
              <span class="probootstrap-number" data-number="8921">0</span>
              <span class="probootstrap-label">Happy Patients</span>
            </div>
          </div>    
          <div class="col-md probootstrap-animate">
            <div class="probootstrap-counter text-center">
              <span class="probootstrap-number" data-number="252">0</span>
              <span class="probootstrap-label">Business Partner</span>
            </div>
          </div>    
        </div>
      </div>
      
    </section>

  <section class="probootstrap-subscribe">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-12">
          <h2 class="h1 text-white">Subscribe Newsletter</h2>
          <p class="lead text-white">Far far away, behind the word mountains, far from the countries Vokalia.</p>
        </div>
      </div>
      <form action="#" method="post">
        <div class="row">
          <div class="col-md-4">
            <input type="text" class="form-control" placeholder="Name">    
          </div>
          <div class="col-md-4 mb-md-0 mb-3">
            <input type="text" class="form-control" placeholder="Email">
          </div>
          <div class="col-md-4">
            <input type="submit" value="Subscribe" class="btn btn-primary btn-block">
          </div>
        
        </div>
      </form>
    </div>
  </section>


  <?php echo $__env->make('frontend.partials.component.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- loader -->
  <div id="probootstrap-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#e1b12c"/></svg></div>
  

  <?php echo $__env->make('frontend.partials.assets.js.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
</body>
</html>