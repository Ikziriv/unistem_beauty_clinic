<!DOCTYPE html>
<html lang="en">
<head>
  <title>Unistem International</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="author" content="RID" />
  
  <link id="favicon" rel="shortcut icon" href="<?php echo e(url('_frontend/img/logo.png')); ?>" type="image/png">
  <link href="https://fonts.googleapis.com/css?family=Work+Sans" rel="stylesheet">
  <?php echo $__env->make('frontend.partials.assets.css.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>
<body>
  <?php echo $__env->make('frontend.partials.component.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- END nav -->
  <?php echo $__env->yieldContent('header'); ?>

  <?php echo $__env->yieldContent('content'); ?>





  <section class="probootstrap-subscribe">
    <div class="container">
      <div class="row mb-5">
        <div class="col-md-12">
          <h2 class="h1 text-white">Subscribe Newsletter</h2>
          <p class="lead text-white">Far far away, behind the word mountains, far from the countries Vokalia.</p>
        </div>
      </div>
      <form action="#" method="post">
        <div class="row">
          <div class="col-md-4">
            <input type="text" class="form-control" placeholder="Name">    
          </div>
          <div class="col-md-4 mb-md-0 mb-3">
            <input type="text" class="form-control" placeholder="Email">
          </div>
          <div class="col-md-4">
            <input type="submit" value="Subscribe" class="btn btn-primary btn-block">
          </div>
        
        </div>
      </form>
    </div>
  </section>


  <?php echo $__env->make('frontend.partials.component.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- loader -->
  <div id="probootstrap-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#e1b12c"/></svg></div>
  

  <?php echo $__env->make('frontend.partials.assets.js.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script type="text/javascript">
     $('#myCarousel').carousel({
        interval: 3000,
     })
  </script>
  
</body>
</html>