
  <comment-form
      post_id="<?php echo e($post->id); ?>"
      placeholder="Your comment"
      button="Comment">
  </comment-form>

