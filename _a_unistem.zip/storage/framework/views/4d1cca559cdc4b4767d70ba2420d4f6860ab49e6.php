<!-- Bootstrap core CSS -->
<link href="<?php echo e(url('_backend/assets/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">

<!--Fonts-->
<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Icons -->
<link href="<?php echo e(url('_backend/assets/css/font-awesome.css')); ?>" rel="stylesheet">

<!-- Custom styles for this template -->
<link href="<?php echo e(url('_backend/assets/css/style.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
