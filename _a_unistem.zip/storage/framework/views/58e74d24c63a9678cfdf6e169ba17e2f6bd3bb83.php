<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <section class="row">
        <?php echo $__env->make('backend.pages.post._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-sm-12">
        <div class="card">
            <div class="card-header">
              <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                   <a class="nav-link active" href="<?php echo e(route('post-create')); ?>">Add</a>
                </li>
              </ul>
            </div>

            <div class="card-block">
              <div class="table-responsive">
                <table class="table table-striped" id="bs4_table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Title</th>
                      <th scope="col">Sub Title</th>
                      <th scope="col">Category</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($value['title']); ?></td>
                      <td><?php echo e($value['sub_title']); ?></td>
                      <td><?php echo e($value->category['name']); ?></td>
                      <td>
                        <div class="dropdown">
                          <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Action
                          </button>
                          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="<?php echo e(route('post-view', $value['id'])); ?>">View</a>
                            <a class="dropdown-item" href="<?php echo e(route('post-edit', $value['id'])); ?>">Edit</a>
                            <form id="delete-form-<?php echo e($value['id']); ?>" 
                                method="post" 
                                action="<?php echo e(route('post-delete', $value['id'])); ?>"
                                style="display: none;">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                            </form>
                            <a class="dropdown-item" href="" onclick="
                              if(confirm('Are You Sure?')) {
                                event.preventDefault();
                                document.getElementById('delete-form-<?php echo e($value['id']); ?>').submit();
                              } else {
                                event.preventDefault();
                              }
                            ">
                            Delete</a>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-sm-12">
                      <div class="card">
                          <div class="card-block">
                            <h4 class="card-title">Not Found</h4>
                          </div>
                      </div>
                    </div><br>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          </div>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>