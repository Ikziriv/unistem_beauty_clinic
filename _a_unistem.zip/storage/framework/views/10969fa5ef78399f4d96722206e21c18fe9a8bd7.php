<?php $__env->startSection('header'); ?>
  <header role="banner" class="probootstrap-header py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-3 mb-4">
          <a href="#" class="mr-auto"><img src="<?php echo e(url('_frontend/img/logo_text.png')); ?>" width="268" height="68" class="hires" alt="Unistem"></a>
        </div>  
        <div class="col-md-9">
          <div class="float-md-right float-none">
          <div class="probootstrap-contact-phone d-flex align-items-top mb-3 float-left">
            <span class="icon mr-2"><i class="icon-phone"></i></span>
            <span class="probootstrap-text"> +6221 29629111 <small class="d-block"><a href="/appointment" class="arrow-link">Appointment <i class="icon-chevron-right"></i></a></small></span>
          </div>
          </div>
        </div>
      </div>
    </div>
  </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="probootstrap-services">
    <div class="container">
      <div class="row no-gutters">
        <div class="col-md-3 pb-5 probootstrap-aside-stretch-left probootstrap-inside">
          <div class="mb-3 pt-5">
            <h2 class="h6">Categories</h2>
            <ul class="list-unstyled probootstrap-light mb-4">
              <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <li><a href="<?php echo e(route('front-blog-list', $v->id)); ?>"><?php echo e($v->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <li><a href="#">Not Set</a></li>
              <?php endif; ?>
            </ul>
          </div>
        </div>
        <div class="col-md-9 pl-md-5 pb-5 pl-0 probootstrap-inside">
          <h1 class="mt-4 mb-4"><?php echo e($blog->title); ?></h1>
          <p><small><?php echo e($blog->sub_title); ?></small>
            <br> <?php echo e($blog->content); ?> </p>
          <p class="mt-3">
            <like
              likes_count="<?php echo e($post->likes_count); ?>"
              liked="<?php echo e($post->isLiked()); ?>"
              item_id="<?php echo e($post->id); ?>"
              item_type="posts"
              logged_in="<?php echo e(Auth::check()); ?>"
            ></like>
          </p>
          <hr>
          <?php echo $__env->make('frontend.pages.comment.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>