<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <?php echo $__env->make('backend.partials.notif.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('backend.partials.notif.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <section class="row">
          <?php echo $__env->make('backend.pages.doctor._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-sm-12">
            <div class="card">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('subdoctor-create')); ?>"> Add</a>
                  </li>
                </ul>
              </div>
              
              <div class="card-block">
                <div class="row">
                  <?php $__empty_1 = true; $__currentLoopData = $subdoctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="col-lg-4 mb-4">
                    <div class="card">
                      <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                          <li class="nav-item dropdown">
                            <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Action</a>
                            <div class="dropdown-menu">
                              <a class="dropdown-item" href="<?php echo e(route('subdoctor-view', $value['id'])); ?>">View</a>
                              <a class="dropdown-item" href="<?php echo e(route('subdoctor-edit', $value['id'])); ?>">Edit</a>
                              <form id="delete-form-<?php echo e($value['id']); ?>" 
                                  method="post" 
                                  action="<?php echo e(route('subdoctor-delete', $value['id'])); ?>"
                                  style="display: none;">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                              </form>
                              <a class="dropdown-item" href="" onclick="
                                if(confirm('Are You Sure?')) {
                                  event.preventDefault();
                                  document.getElementById('delete-form-<?php echo e($value['id']); ?>').submit();
                                } else {
                                  event.preventDefault();
                                }
                              ">
                              Delete</a>
                            </div>
                          </li>
                        </ul>
                      </div>
                      <div class="card-block">
                        <h4 class="card-title"><?php echo e($value['name']); ?></h4>
                        <small><?php echo e($value['sub_title']); ?></small>
                        <p>"<?php echo e($value['quote']); ?>"</p>
                      </div>
                    </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <div class="col-sm-12">
                    <div class="card">
                        <div class="card-block">
                          <h4 class="card-title">Not Found</h4>
                        </div>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
            
          </div>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $('#bs-example-navbar-collapse-1').on('show.bs.collapse', function() {
    $('.nav-pills').addClass('nav-stacked');
  });

  //Unstack menu when not collapsed
  $('#bs-example-navbar-collapse-1').on('hide.bs.collapse', function() {
      $('.nav-pills').removeClass('nav-stacked');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>