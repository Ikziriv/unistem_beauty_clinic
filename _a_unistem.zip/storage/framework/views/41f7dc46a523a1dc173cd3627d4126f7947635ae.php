<div class="col-sm-12">
  <div class="card">
    <div class="card-block">
      <ul class="nav nav-pills">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Message</a>
          <div class="dropdown-menu">
            <a class="dropdown-item" href="#">Inbox</a>
          </div>
        </li>
      </ul>
    </div>
  </div>
</div>