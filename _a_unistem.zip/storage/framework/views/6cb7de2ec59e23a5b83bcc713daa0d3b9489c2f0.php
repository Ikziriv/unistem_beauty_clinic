<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <section class="row">
          <div class="col-sm-12">
              <div class="pull-left">
                  <div class="card" style="border-style: none;">
                    <div class="card-body">
                      <i class="fa fa-file-o fa-3x"></i> <span class="badge badge-primary badge-pill">Total</span>
                    </div>
                  </div>
                  <br>
              </div>
          </div>
      </section>
      <section class="row">
        <div class="col-sm-6">
          <a href="<?php echo e(route('post')); ?>">
          <div class="card">
            <div class="card-block">
              <div class="card-body">
                <div class="clearfix">
                  <div class="p-2 ml-auto">
                    <h4 class="text-card lead">Blog</h4>
                  </div>
                  <div class="p-2 pull-right">
                    <b><?php echo e($post); ?></b>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </a>
        </div>
        <div class="col-sm-6">
          <a href="<?php echo e(route('subdoctor')); ?>">
          <div class="card">
            <div class="card-block">
              <div class="card-body">
                <div class="clearfix">
                  <div class="p-2 ml-auto">
                    <h4 class="text-card lead">Doctor Members</h4>
                  </div>
                  <div class="p-2 pull-right">
                    <b><?php echo e($subdoc); ?></b>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </a>
        </div>
        <div class="col-sm-12"><br></div>
        <div class="col-sm-6">
          <a href="<?php echo e(route('service')); ?>">
          <div class="card">
            <div class="card-block">
              <div class="card-body">
                <div class="clearfix">
                  <div class="p-2 ml-auto">
                    <h4 class="text-card lead">Main Service</h4>
                  </div>
                  <div class="p-2 pull-right">
                    <b><?php echo e($subserv); ?></b>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </a>
        </div>
        <div class="col-sm-6">
          <a href="<?php echo e(route('client')); ?>">
          <div class="card">
            <div class="card-block">
              <div class="card-body">
                <div class="clearfix">
                  <div class="p-2 ml-auto">
                    <h4 class="text-card lead">Client</h4>
                  </div>
                  <div class="p-2 pull-right">
                    <b><?php echo e($client); ?></b>
                  </div>
                </div>
              </div>
            </div>
          </div>
          </a>
        </div>
              
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>