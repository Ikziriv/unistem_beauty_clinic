<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <section class="row">
          <?php echo $__env->make('backend.pages.menu._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-sm-12">

            <?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card text-center">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('contact-edit', $value['id'])); ?>">Edit</a>
                  </li>
                </ul>
              </div>
              
              <div class="card-block">
                <div class="card text-left" style="width: 100%; border-style: none;">
                  <div class="card-body">
                    <br>
                      <h4 class="card-title"><?php echo e($value['title']); ?></h4>
                      <p class="card-text"><?php echo $value['content']; ?></p>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $('#bs-example-navbar-collapse-1').on('show.bs.collapse', function() {
    $('.nav-pills').addClass('nav-stacked');
  });

  //Unstack menu when not collapsed
  $('#bs-example-navbar-collapse-1').on('hide.bs.collapse', function() {
      $('.nav-pills').removeClass('nav-stacked');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>