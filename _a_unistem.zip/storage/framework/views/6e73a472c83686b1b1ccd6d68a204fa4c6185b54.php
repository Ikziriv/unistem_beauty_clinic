<div class="col-sm-12">
  <div class="card">
    <div class="card-block">
      <ul class="nav nav-pills">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('post')); ?>">News & Advice</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('category')); ?>">Category</a>
        </li>
      </ul>
    </div>
  </div>
</div>