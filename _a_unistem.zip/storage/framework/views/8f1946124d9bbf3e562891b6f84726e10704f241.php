  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/open-iconic-bootstrap.min.css')); ?>">
  
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/owl.carousel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/owl.theme.default.min.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/icomoon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/flaticon.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/animate.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/bootstrap-datepicker.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('_frontend/css/style.css')); ?>">