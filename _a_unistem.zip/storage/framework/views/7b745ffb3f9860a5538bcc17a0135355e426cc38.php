  <script src="<?php echo e(url('_frontend/js/jquery-3.2.1.min.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/owl.carousel.min.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/jquery.waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/bootstrap-datepicker.js')); ?>"></script>
  <script src="<?php echo e(url('_frontend/js/jquery.animateNumber.min.js')); ?>"></script>

  <script src="<?php echo e(url('_frontend/js/main.js')); ?>"></script>