<h5 class="text-right">Comment : <?php echo e($post->comments_count); ?></h5>

<?php echo $__env->make('frontend.pages.comment.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<comment-list
    post_id="<?php echo e($post->id); ?>"
    loading_comments="Load comments"
    data_confirm="Are you sure you want to delete this comment?">
</comment-list>
