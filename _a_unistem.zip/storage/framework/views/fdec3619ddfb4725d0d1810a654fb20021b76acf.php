<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <?php echo $__env->make('backend.partials.notif.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('backend.partials.notif.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <section class="row">
          <?php echo $__env->make('backend.pages.menu._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-sm-12">

            <div class="card text-center">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('dept')); ?>">Back</a>
                  </li>
                </ul>
              </div>
              
              <div class="card-block">
                <div class="card text-left" style="width: 100%; border-style: none;">
                  <div class="card-body">
                    <form class="form-horizontal" action="<?php echo e(route('dept-update', $department->id)); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <fieldset>
                      <div class="form-group">
                        <label class="col-12 control-label no-padding" for="img_path">Image</label>
                        <div class="col-6 no-padding">
                          <input id="img_path" name="img_path" type="file"  value="" class="form-control">
                        </div>
                        <div class="col-6 no-padding">
                          <img src="<?php echo e($department->img_path); ?>">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-12 control-label no-padding" for="name">Name</label>
                        <div class="col-12 no-padding">
                          <input id="name" name="name" type="text" value="<?php echo e($department->name); ?>" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-12 control-label no-padding" for="description">Description</label>
                        <div class="col-12 no-padding">
                          <textarea class="form-control" id="content" name="content"><?php echo e($department->description); ?></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                          <div class="col-12 widget-right no-padding">
                            <button type="submit" class="btn btn-primary btn-md float-right">Edit</button>
                          </div>
                        </div>
                    </fieldset>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $('#bs-example-navbar-collapse-1').on('show.bs.collapse', function() {
    $('.nav-pills').addClass('nav-stacked');
  });

  //Unstack menu when not collapsed
  $('#bs-example-navbar-collapse-1').on('hide.bs.collapse', function() {
      $('.nav-pills').removeClass('nav-stacked');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>