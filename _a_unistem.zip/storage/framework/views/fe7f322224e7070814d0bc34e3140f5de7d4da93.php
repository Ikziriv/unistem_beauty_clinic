<?php $__env->startSection('style'); ?>
<style type="text/css">
  img { height: 120px;}
  .object-fit_fill { object-fit: fill }
  .object-fit_contain { object-fit: contain }
  .object-fit_cover { object-fit: cover }
  .object-fit_none { object-fit: none }
  .object-fit_scale-down { object-fit: scale-down }
  #img_fit{
    float: left;
    width: 40%;
    margin: 0 30px 20px 0; display: block;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <?php echo $__env->make('backend.partials.notif.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('backend.partials.notif.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <section class="row">
          <?php echo $__env->make('backend.pages.menu._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php $__empty_1 = true; $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-sm-12">
            <div class="card text-center">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('about-edit', $value['id'])); ?>">Edit</a>
                  </li>
                </ul>
              </div>
            </div><br>
          </div>

          <div class="col-sm-12">
            <div class="card">
              <div class="card-block">
                <br>
                <img class="card-img-top object-fit_contain" id="img_fit" src="<?php echo e(asset('storage/'. $value['img_head'] .'')); ?>" data-holder-rendered="true">
                <div class="card-body">
                  <h4 class="card-title"><?php echo e(str_limit($value['title'], 40)); ?></h4>
                  <p class="card-text my_text"><?php echo str_limit($value['content'], 300); ?></p>
                </div>
              </div>
              <div class="card-footer">
                <?php echo e($value['created_at']); ?>

              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="col-sm-12">
            <div class="card">
                <div class="card-block">
                  <h4 class="card-title">Not Found</h4>
                </div>
            </div>
          </div>
          <?php endif; ?>

          <div class="col-sm-12">
            <div class="card">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('about-upload')); ?>"">Partner Upload</a>
                  </li>
                </ul>
              </div>
              <div class="card-block">
                <h4 class="card-title">Partner</h4>
                <hr>
                <div class="row">
                  <?php $__empty_1 = true; $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <div class="col-md-4">
                    <ul class="nav nav-tabs card-header-tabs">
                      <li class="nav-item dropdown">
                        <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Action</a>
                        <div class="dropdown-menu">
                          <?php if($value['link_path']==NULL): ?>
                            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#about_partner_modal">Insert URL</a>
                          <?php else: ?>
                            <a class="dropdown-item edit-modal" data-id="<?php echo e($value['id']); ?>" data-link="<?php echo e($value['link_path']); ?>">Edit URL</a>
                          <?php endif; ?>
                          <form id="delete-form-<?php echo e($value['id']); ?>" 
                              method="post" 
                              action="<?php echo e(route('about-partner-delete', $value['id'])); ?>"
                              style="display: none;">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                          </form>
                          <a class="dropdown-item" href="" onclick="
                            if(confirm('Are You Sure?')) {
                              event.preventDefault();
                              document.getElementById('delete-form-<?php echo e($value['id']); ?>').submit();
                            } else {
                              event.preventDefault();
                            }
                          ">
                          Delete</a>
                        </div>
                      </li>
                    </ul><br>
                    <a href="<?php echo e($value['link_path']); ?>" target="_blank">
                      <img class="card-img-top img-thumbnail object-fit_contain" id="img_fit" src="<?php echo e(asset('storage/'. $value['img_path'] .'')); ?>" data-holder-rendered="true">
                    </a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <div class="col-sm-12">
                    <div class="card">
                        <div class="card-block">
                          <h4 class="card-title">Not Found</h4>
                        </div>
                    </div>
                  </div>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>

<?php echo $__env->make('backend.pages.menu.about.modal.insert_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('backend.pages.menu.about.modal.edit_modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $('#bs-example-navbar-collapse-1').on('show.bs.collapse', function() {
    $('.nav-pills').addClass('nav-stacked');
  });

  //Unstack menu when not collapsed
  $('#bs-example-navbar-collapse-1').on('hide.bs.collapse', function() {
      $('.nav-pills').removeClass('nav-stacked');
  });
</script>
<script type="text/javascript">
    $(document).on('click', '.edit-modal', function() {
        $('#edit_id').val($(this).data('id'));
        $('#edit_link').val($(this).data('link'));
        $('#about_partner_modal_edit').modal('show');
    });
    $('.my_text').editable({
        type: 'wysiwyg',
        editor: ed,
        onSubmit: function submitData(content) {
           alert(content.previous);
        },
        submit: 'save',
        cancel: 'cancel'
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>