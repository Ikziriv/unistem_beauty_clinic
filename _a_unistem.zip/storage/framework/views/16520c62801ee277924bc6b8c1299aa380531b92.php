<?php $__env->startSection('content'); ?>
<section class="row">
  <div class="col-sm-12">
      <section class="row">
          <?php echo $__env->make('backend.pages.menu._partials.nav-pills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-sm-12">


            <div class="card text-center">
              <div class="card-header">
                <ul class="nav nav-tabs card-header-tabs">
                  <li class="nav-item">
                    <a class="nav-link active" href="<?php echo e(route('promo-create')); ?>">Upload</a>
                  </li>
                </ul>
              </div>
              
              <div class="card-block">
                <div class="container">
                  <div class="row">
                    <div class="col-12">
                      <form class="form-inline justify-content-end">
                        <div class="form-group mb-2">
                          <input type="date" id="search_promo" name="search_promo" class="form-control w-100">
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary ml-2 mb-2">Search</button>
                      </form>
                    </div>
                  </div><br>
                  <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $promo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-4">
                    <div class="card">
                      <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                          <li class="nav-item dropdown">
                            <a class="nav-link active dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Action</a>
                            <div class="dropdown-menu">
                              <form id="delete-form-<?php echo e($value['id']); ?>" 
                                  method="post" 
                                  action="<?php echo e(route('promo-delete', $value['id'])); ?>"
                                  style="display: none;">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                              </form>
                              <a class="dropdown-item" href="" onclick="
                                if(confirm('Are You Sure?')) {
                                  event.preventDefault();
                                  document.getElementById('delete-form-<?php echo e($value['id']); ?>').submit();
                                } else {
                                  event.preventDefault();
                                }
                              ">
                              Delete</a>
                            </div>
                          </li>
                        </ul>
                        </div>
                        <div class="card-block" style="width: 100%;">
                          <img class="img-thumbnail img-responsive" src="<?php echo e(asset('storage/'. $value['img_promo'] .'')); ?>">
                          <small class="text-center"><?php echo e($value['promo_date']); ?></small>
                        </div>
                    </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-sm-12">
                      <div class="card">
                          <div class="card-block">
                            <h4 class="card-title">Not Found</h4>
                          </div>
                      </div>
                    </div>
                    <?php endif; ?>
                  </div>
                  </div>
                </div>
              </div>
            </div>

            <br>
      </section>
      <section class="row">
          
      </section>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
  $('#bs-example-navbar-collapse-1').on('show.bs.collapse', function() {
    $('.nav-pills').addClass('nav-stacked');
  });

  //Unstack menu when not collapsed
  $('#bs-example-navbar-collapse-1').on('hide.bs.collapse', function() {
      $('.nav-pills').removeClass('nav-stacked');
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>