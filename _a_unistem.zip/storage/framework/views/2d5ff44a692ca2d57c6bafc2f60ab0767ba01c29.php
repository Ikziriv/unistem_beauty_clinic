<div class="col-sm-12">
  <div class="card">
    <div class="card-block">
      <ul class="nav nav-pills">
        <li class="nav-item">
          <a class="nav-link" href="/hasci/header">Header</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/hasci/body">Body</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/hasci/link">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/hasci/metode">Metode</a>
        </li>
      </ul>
    </div>
  </div>
</div>