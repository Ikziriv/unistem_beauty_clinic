<ul class="nav nav-pills flex-column sidebar-nav">
    <li class="nav-item"><a class="nav-link" href="{{route('beranda')}}"><em class="fa fa-dashboard"></em> Dashboard <span class="sr-only">(current)</span></a></li>
    <li class="nav-item"><a class="nav-link" href="/post"><em class="fa fa-folder"></em> Blog</a></li>
    <li class="nav-item"><a class="nav-link" href="/doctor"><em class="fa fa-user-md"></em> Doctor</a></li>
    <li class="nav-item"><a class="nav-link" href="/client"><em class="fa fa-user"></em> Client</a></li>
    <li class="nav-item"><a class="nav-link" href="/service"><em class="fa fa-clone"></em> Menu</a></li>
    <li class="nav-item"><a class="nav-link" href="/menu/appointment"><em class="fa fa-file"></em> Appointment</a></li>
    <li class="nav-item"><a class="nav-link" href="#"><em class="fa fa-users"></em> Staff</a></li>
    <li class="nav-item"><a class="nav-link" href="#"><em class="fa fa-user"></em> Careers</a></li>
    <li class="nav-item"><a class="nav-link" href="/hasci/header"><em class="fa fa-clone"></em> HASCI</a></li>
    <li class="nav-item"><a class="nav-link" href="/testimonial"><em class="fa quote-left"></em> Testimonial</a></li>
</ul>