<h2>Welcome To Bamed Skin Care</h2>
<br/>
<p>
	Name {{$name}}
	Thanks For Contribute, Mr/Mrs {{$email}}
	Your Password : {{$password}}
</p>