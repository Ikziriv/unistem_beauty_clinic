<h2>Welcome To Bamed Skin Care</h2>
<br/>
<p>
	Dear, Mr/Mrs {{$email}} <br>
	Your Password : {{$password}}
</p>